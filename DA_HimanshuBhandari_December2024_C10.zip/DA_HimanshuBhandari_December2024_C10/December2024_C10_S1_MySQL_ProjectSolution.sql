-- Focus Area 7: Airbnb Data Exploration using MySQL

-- Objective 1: Analyze listings and host metrics across locations

-- Q1) Which 5 cities have the highest average listings prices, and how many listings does each have?
-- Ans.
select city, count(*) as listings_count, avg(price) as avg_listing_price from df_cleaned
group by city order by avg_listing_price desc limit 5;


-- Q2) Which hosts have more than 5 listings, and what is their average rating and response rate?
-- Ans.
select host_id,host_name,count(*) as listings_count, avg(review_scores_rating) as avg_rating,
avg(host_response_rate) as avg_response_rate from df_cleaned 
group by host_id, host_name having listings_count > 5 order by avg_rating desc; 

-- Objective 2: Automate tasks using Stored procedure and Trigger

-- 1) Create a stored procedure that accepts city name as input and returns the number of listings , average price and average review score for that city
-- Ans.
delimiter //
create procedure get_city_info(in city_name varchar(100))
begin
     select city, count(*) as total_listings,
     avg(price) as avg_price,
     avg(review_scores_rating) as avg_review_score
     from df_cleaned where city = city_name
     group by city;
end //
delimiter ;

-- calling the stored procedure
call get_city_info("paris");

-- 2) Find Top N hosts by average price in a city
-- Ans.
delimiter //
create procedure get_top_hosts_by_price(in city_name varchar (100), in top_n int)
begin
     select host_id,host_name,count(*) as total_listings, 
     avg(price) as avg_price from df_cleaned 
     where city = city_name
     group by host_id, host_name
     order by avg_price desc
     limit top_n ;
end //
delimiter ;


call get_top_hosts_by_price("Berlin", 5) ;     